dicx = {
    'f'  :'ᚠ', #2,   ['F'] ],
    'u'  :'ᚢ', #3,   ['U', 'V'] ],
    'v'  :'ᚢ', #3,   ['U', 'V'] ],
    'th' :'ᚦ', #5,   ['TH'] ],
    'r'  :'ᚱ', #11,  ['R'] ],
    'c'  :'ᚳ', #13,  #['C', 'K'] ],
    'k'  :'ᚳ', #13,  #['C', 'K'] ],
    'q'  :'ᚳ', #13,  #['C', 'K'] ],
    'w'  :'ᚹ', #19,  ['W'] ],
    'h'  :'ᚻ', #23,  ['H'] ],
    'j'  :'ᛄ', #37,  ['J'] ],
    'eo' :'ᛇ', #41,  ['EO'] ],
    'p'  :'ᛈ', #43,  ['P'] ],
    'x'  :'ᛉ', #47,  ['X'] ],
    's'  :'ᛋ', #53,  ['S', 'Z'] ],
    'z'  :'ᛋ', #53,  ['S', 'Z'] ],
    't'  :'ᛏ', #59,  ['T'] ],
    'b'  :'ᛒ', #61,  ['B'] ],
    'm'  :'ᛗ', #71,  ['M'] ],
    'l'  :'ᛚ', #73,  ['L'] ],
    'ing': 'ᛝ', #79,  ['(I)NG', 'ING', 'NG'] ],
    'ng' : 'ᛝ', #79,  ['(I)NG', 'ING', 'NG'] ],
    'g'  :'ᚷ', #17,  ['G'] ],
    'n'  :'ᚾ', #29,  ['N'] ],
    'oe' :'ᛟ', #83,  ['OE'] ],
    'd'  :'ᛞ', #89,  ['D'] ],
    'ae' :'ᚫ', #101, ['AE'] ],
    'y'  :'ᚣ', #103, ['Y'] ],
    'ia' :'ᛡ', #107, ['I(A/O)', 'IA', 'IO'] ],
    'io' :'ᛡ', #107, ['I(A/O)', 'IA', 'IO'] ],
    'o'  :'ᚩ', #7,   ['O'] ],
    'i'  :'ᛁ', #31,  ['I'] ],
    'ea' :'ᛠ', #109, ['EA'] ],
    'a'  :'ᚪ', #97,  ['A'] ],
    'e'  :'ᛖ', #67,  ['E'] ],
    #];
}

Nfile = 'wordlist.194433.txt'
wordlist = None
with open(Nfile, 'r') as fob:
    wordlist = fob.readlines()
    fob.close()

print('Start Converting...')

def convertion(i):
    for k in dicx:
        i = i.replace(k, dicx[k])
    return i.encode()
    

with open('R'+Nfile, 'wb') as fob:
    for i in wordlist:
        fob.write(convertion(i.lower()))
    fob.close()

print('Converting Done!')
    
