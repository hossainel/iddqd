Nfile = 'Rwordlist.194433.txt'
wordlist = None
with open(Nfile, 'rb') as fob:
    wordlist = fob.readlines()
    fob.close()

print('Start Converting...')

for i in wordlist:
    txt = 'Rwordbox/{0}.txt'.format(len(i)//3)
    with open(txt,'ab+') as fob:
        fob.write(i)
        fob.close()

print('Converting Done!')
    
