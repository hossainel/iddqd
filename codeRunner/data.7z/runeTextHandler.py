
with open('liber', 'rb') as fob:
    liber = fob.read()
    fob.close()

line = 0

f = liber.find(b'Delimiters\n')
f = len(b'Delimiters\n')+f
f0 = liber.find(b'\n\n')-1

info = liber.decode()[f:f0]
info = info.split('\n')
"""Delimiters
Word     : -
Clause   : .
Paragraph: &
Segment  : $
Chapter  : §
Line     : /
Page     : %"""

def deco():
    print('-'*30)


if input('Do you like to see the info file? y/[n]') == 'y':
    deco()
    for i in info:
        print(i)
    deco()
    
chapters = liber.decode()[f0:].split('§')[:-1]
pages = chapters[0].split('%')[:-1]
print('Opened Chapter: 1')
page = pages[int(input('Enter a page number to view the page(0-74): '))]
deco()

seg = False
par = False
clo = False
if '$' in page:
    print('The page has multiple Segments.')
    seg = True
    deco()
if '&' in page:
    print('The page has multiple Paragraph.')
    par = True
    deco()
if '.' in page:
    print('The page has multiple Clause.')
    clo = True
    deco()


print(page)
deco()

lines = page.split('/')[:-1]

que = ''

for i in lines:
    que = que + i
que = que.replace('\n','')

if clo:
    clauses = que.split('.')
else:
    clauses = que
for j in clauses:
    for i in j.split('-'):
        print(len(i),i)
    deco()

input('Test ok')
exit()
